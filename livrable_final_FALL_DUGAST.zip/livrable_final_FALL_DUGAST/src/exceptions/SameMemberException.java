package exceptions;

public class SameMemberException extends Exception {
	public SameMemberException(String message){
		super(message);
	}
}
